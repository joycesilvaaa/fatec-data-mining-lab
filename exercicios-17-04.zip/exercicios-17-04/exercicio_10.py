import pandas as pd

def detectar_aceleracao(leituras):
    df = pd.DataFrame(leituras, columns=['valor'])
    # Diferença simples (Delta) [cite: 73]
    df['delta'] = df['valor'].diff()
    # Diferença da diferença (Aceleração/Delta do Delta) 
    df['aceleracao'] = df['delta'].diff()
    
    # Alerta binário para ritmo de crescimento exponencial 
    df['alerta_exp'] = (df['aceleracao'] > 0).astype(int)
    return df

sensor_data = [100, 105, 115, 130, 155] # Note que o aumento está acelerando
print(detectar_aceleracao(sensor_data))