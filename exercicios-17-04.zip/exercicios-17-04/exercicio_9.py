import pandas as pd

def categorizar_turnos_log(lista_horarios):
    df = pd.DataFrame(lista_horarios, columns=['hora'])
    
    # Define os intervalos para os turnos: 0-6 (Madrugada), 6-18 (Comercial), 18-24 (Noite) 
    bins = [0, 6, 18, 24]
    labels = ['Madrugada', 'Comercial', 'Noite'] [cite: 77]
    
    # Transforma o dado numérico contínuo em categorias 
    df['turno'] = pd.cut(df['hora'], bins=bins, labels=labels, right=False)
    
    return df

# Exemplo: Logs de horários variados (00h às 23h)
horarios = [2, 8, 14, 20, 23] [cite: 77]
print(categorizar_turnos_log(horarios))