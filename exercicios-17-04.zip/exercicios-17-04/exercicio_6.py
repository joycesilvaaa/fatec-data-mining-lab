import pandas as pd

def analisar_comprometimento_credito(renda_mensal, divida_total):
    df = pd.DataFrame({
        'renda_mensal': renda_mensal,
        'divida_total': divida_total
    })
    
    # Razão de Comprometimento: Dívida / Renda 
    df['razao_comprometimento'] = df['divida_total'] / df['renda_mensal'] [cite: 74]
    
    return df

# Exemplo de uso
dados_clientes = {
    'renda_mensal': [5000, 2000, 10000],
    'divida_total': [1500, 1500, 1500]
}
print(analisar_comprometimento_credito(dados_clientes['renda_mensal'], dados_clientes['divida_total']))