import pandas as pd
import numpy as np

def tratar_nulos_com_flag(dados):
    df = pd.DataFrame(dados, columns=['leitura'])
    # 1. Cria o Indicador de Omissão [cite: 75]
    df['flag_erro_leitura'] = df['leitura'].isna().astype(int)
    # 2. Preenche a lacuna original (ex: com a mediana) [cite: 76]
    df['leitura'] = df['leitura'].fillna(df['leitura'].median())
    return df

dados = [22.5, np.nan, 23.1, np.nan, 22.8]
print(tratar_nulos_com_flag(dados))