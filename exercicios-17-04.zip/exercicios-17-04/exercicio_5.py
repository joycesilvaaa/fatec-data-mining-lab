import pandas as pd

def calcular_tendencia_sensor(leitura_atual, leitura_anterior):
    # Cálculo do Delta (Variação bruta)
    delta = leitura_atual - leitura_anterior [cite: 73]
    
    # Cálculo da Evolução Percentual
    evolucao_pct = (delta / leitura_anterior) * 100 [cite: 73]
    
    # Sinalização de tendência
    tendencia = 1 if delta > 0 else 0 # 1 para Crescimento, 0 para Queda 
    
    return {
        "delta": delta,
        "evolucao_percentual": f"{evolucao_pct:.2f}%",
        "flag_crescimento": tendencia
    }

# Exemplo: Momento A (150) e Momento B (185)
resultado = calcular_tendencia_sensor(185, 150)
print(f"Resultado do Sensor: {resultado}")