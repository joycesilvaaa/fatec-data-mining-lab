import pandas as pd

vendas = {'produto': ['A', 'B', 'C', 'D'], 'volume': [500, 1200, 300, 800]}
df = pd.DataFrame(vendas)

df['ranking'] = df['volume'].rank(ascending=False)
print(df.sort_values(by='ranking'))