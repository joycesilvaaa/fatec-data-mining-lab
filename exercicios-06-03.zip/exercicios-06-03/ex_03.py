import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 1. Simulando um formulário com muitos dados ausentes
dados = {
    'Nome_Completo': ['Ana', 'Beto', 'Carla', None, 'Edu'],
    'Email': ['ana@ex.com', None, 'carla@ex.com', None, 'edu@ex.com'],
    'Telefone': [None, None, '9999-0000', None, '8888-1111'],
    'Idade': [25, 30, None, None, 40],
    'Cargo': ['Engenheira', 'Analista', None, None, 'Gerente']
}

df = pd.DataFrame(dados)

# 2. Configurando o estilo visual
plt.figure(figsize=(10, 6))

# 3. Criando o Mapa de Calor (Heatmap)
# df.isnull() identifica os vazios
# cbar=False remove a barra lateral de legenda para simplificar
# yticklabels=False esconde os números das linhas para focar nas colunas
sns.heatmap(df.isnull(), yticklabels=False, cbar=False, cmap='viridis')

plt.title('Mapa de Qualidade de Dados: Áreas em Amarelo representam Dados Faltantes')
plt.show()