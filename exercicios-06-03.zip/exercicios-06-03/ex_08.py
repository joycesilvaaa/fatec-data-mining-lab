import pandas as pd

# 1. Simulando a base do laboratório de eletrônica
dados = {
    'Componente': ['Resistor 10k', 'Capacitor 100uF', 'LED Vermelho', 'Transistor BC548', 'Protoboard'],
    'Quantidade_Estoque': [150, -20, 45.5, 0, 12] 
}

df = pd.DataFrame(dados)

# 2. Criando filtros de integridade
# Filtro A: Quantidade negativa
erro_negativo = df['Quantidade_Estoque'] < 0

# Filtro B: Quantidade não inteira (ex: 45.5 resistores)
# O operador % 1 verifica o resto da divisão por 1. Se for diferente de 0, não é inteiro.
erro_fracionado = df['Quantidade_Estoque'] % 1 != 0

# 3. Combinando os erros para isolar as falhas
df_falhas = df[erro_negativo | erro_fracionado].copy()

print("--- Relatório de Erros de Integridade de Estoque ---")
if df_falhas.empty:
    print("Todos os dados estão matematicamente consistentes.")
else:
    print(df_falhas)