import pandas as pd

# 1. Simulando a base com milhares de registros (Dados + Erros de Digitação)
dados = {
    'Sistema_Operacional': (
        ['Ubuntu'] * 5000 +      # 50%
        ['Debian'] * 3000 +      # 30%
        ['Armbian'] * 1500 +     # 15%
        ['Ubuntuu'] * 150 +      # 1.5% (Erro)
        ['Debian10'] * 100 +     # 1%   (Erro/Variação)
        ['Armmbiian'] * 50       # 0.5% (Erro)
    )
}

df = pd.DataFrame(dados)

# 2. Calculando a proporção de cada categoria (de 0 a 1)
proporcoes = df['Sistema_Operacional'].value_counts(normalize=True)

# 3. Identificando as categorias que representam menos de 5% (0.05)
categorias_raras = proporcoes[proporcoes < 0.05].index

# 4. Isolando esses registros para análise de erro
df_erros = df[df['Sistema_Operacional'].isin(categorias_raras)]

print("--- Categorias identificadas como raras (< 5%) ---")
print(proporcoes[proporcoes < 0.05])

print(f"\nTotal de linhas com possíveis erros: {len(df_erros)}")