import pandas as pd
import numpy as np

# 1. Simulando o lote de dados recebido
dados = {
    'ID_Sensor': [101, 102, 103, 104, 105],
    'Temperatura_C': ['23.5', '24.1', 'falha_sinal', '22.8', 'erro_conexao']
}

df = pd.DataFrame(dados)

# 2. Convertendo a coluna de forma segura
# 'coerce' transforma o que não é número em valores nulos (NaN)
df['Temperatura_C_Numerica'] = pd.to_numeric(df['Temperatura_C'], errors='coerce')

# 3. Filtrando as linhas onde a conversão falhou
# O método isna() identifica onde os valores ficaram nulos após a tentativa de conversão
falhas = df[df['Temperatura_C_Numerica'].isna()]

print("--- Registros com falha na telemetria ---")
print(falhas[['ID_Sensor', 'Temperatura_C']])