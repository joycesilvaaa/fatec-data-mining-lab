import pandas as pd
import numpy as np

# 1. Criação do DataFrame com dois sensores em escalas diferentes
dados = {
    'Sensor_ID': ['A', 'A', 'A', 'A', 'A', 'A', 'B', 'B', 'B', 'B', 'B', 'B'],
    'Valor_Leitura': [10, 12, 11, 13, 50, 12, 100, 105, 102, 108, 10, 104]
}
# Nota: O 50 é outlier para o Sensor A (escala 10), e o 10 é outlier para o Sensor B (escala 100)
df = pd.DataFrame(dados)

# 2. Função para identificar outliers dentro de um grupo
def buscar_outliers_grupo(grupo):
    q1 = grupo.quantile(0.25)
    q3 = grupo.quantile(0.75)
    iqr = q3 - q1
    ls = q3 + 1.5 * iqr
    li = q1 - 1.5 * iqr
    
    # Retorna uma Série Booleana indicando quem é outlier naquele grupo
    return (grupo < li) | (grupo > ls)

# 3. Aplicando o GroupBy e filtrando
# O transform executa a função mantendo o índice original do DataFrame
df['Eh_Outlier'] = df.groupby('Sensor_ID')['Valor_Leitura'].transform(buscar_outliers_grupo)

# 4. Criando um DataFrame apenas com as anomalias detectadas
anomalias = df[df['Eh_Outlier'] == True]

print("--- DataFrame Completo com Marcação ---")
print(df)
print("\n--- Apenas as Anomalias (Independente por Sensor) ---")
print(anomalias)