import numpy as np

# 1. Dado o vetor de tempo de processamento
tempos = [12, 15, 14, 13, 16, 12, 14, 150, 13, 15]

# 2. Calcule os percentis 25, 50 e 75
p25 = np.percentile(tempos, 25)
p50 = np.percentile(tempos, 50)
p75 = np.percentile(tempos, 75)

# 3. Imprima os resultados
print(f"Percentil 25: {p25}")
print(f"Percentil 50: {p50}")
print(f"Percentil 75: {p75}")