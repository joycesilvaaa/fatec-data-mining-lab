import pandas as pd

# Reutilizando os dados e cálculos do Exercício 7
dados = {
    'ID_Maquina': [1, 2, 3, 4, 5], 
    'Uso_Memoria_MB': [2048, 2100, 2050, 8192, 2080]
}
df = pd.DataFrame(dados)

# 1. Calculando os limites novamente
q1 = df['Uso_Memoria_MB'].quantile(0.25)
q3 = df['Uso_Memoria_MB'].quantile(0.75)
iqr = q3 - q1

limite_inferior = q1 - 1.5 * iqr
limite_superior = q3 + 1.5 * iqr

# 2. Criando a Máscara Booleana
# Queremos valores que sejam MAIORES que o limite inferior E MENORES que o limite superior
mascara = (df['Uso_Memoria_MB'] >= limite_inferior) & (df['Uso_Memoria_MB'] <= limite_superior)

# 3. Aplicando a máscara para criar o novo DataFrame (Normalidade)
df_normal = df[mascara]

# Exibição dos resultados
print(f"Limites de Normalidade: {limite_inferior} até {limite_superior}")
print("\n--- DataFrame Original ---")
print(df)
print("\n--- DataFrame de Operação Normal (Sem Anomalias) ---")
print(df_normal)