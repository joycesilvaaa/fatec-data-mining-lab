dados = [100, 150, 200, 250, 300, 350]

# 1. Encontrar o ponto médio usando divisão inteira
tamanho = len(dados)
meio = tamanho // 2

# 2. Dividir a lista em duas fatias (slices)
# Como o enunciado garante que é par, não precisamos tratar restos
metade_inferior = dados[:meio]  # [100, 150, 200]
metade_superior = dados[meio:]  # [250, 300, 350]

# 3. Calcular a mediana de cada metade (que serão Q1 e Q3)
# Para listas de 3 elementos (ímpar), a mediana é o elemento central (índice 1)
def calcular_mediana_simples(lista):
    n = len(lista)
    m = n // 2
    if n % 2 != 0:
        # Se a fatia for ímpar, pega o valor do meio
        return lista[m]
    else:
        # Se a fatia fosse par, seria a média dos dois centrais
        return (lista[m-1] + lista[m]) / 2

q1 = calcular_mediana_simples(metade_inferior)
q3 = calcular_mediana_simples(metade_superior)

print(f"Metade Inferior: {metade_inferior} -> Q1: {q1}")
print(f"Metade Superior: {metade_superior} -> Q3: {q3}")