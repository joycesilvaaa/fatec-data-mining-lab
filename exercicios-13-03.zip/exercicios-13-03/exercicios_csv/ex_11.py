import pandas as pd

# 1. Carregar o arquivo CSV
df = pd.read_csv('dados_sensores.csv')

# 2. Verificar a quantidade de dados ausentes (NaN) por coluna
ausentes = df.isna().sum()
print("--- Quantidade de dados ausentes ---")
print(ausentes)

# 3. Calcular as medianas das colunas numéricas
# Nota: O pandas ignora os NaNs automaticamente ao calcular a mediana
mediana_temp = df['temperatura_celsius'].median()
mediana_pressao = df['pressao_psi'].median()

# 4. Aplicar o .fillna() para substituir os NaNs
# Podemos passar um dicionário para tratar múltiplas colunas de uma vez
df['temperatura_celsius'] = df['temperatura_celsius'].fillna(mediana_temp)
df['pressao_psi'] = df['pressao_psi'].fillna(mediana_pressao)

# 5. Verificar se ainda restam dados ausentes após o tratamento
print("\n--- Pós-tratamento (Check de NaNs) ---")
print(df.isna().sum())

# Opcional: Mostrar as primeiras linhas para conferir os dados
print("\n--- Primeiras linhas do DataFrame tratado ---")
print(df.head())