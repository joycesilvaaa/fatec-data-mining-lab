import pandas as pd

# 1. Carregando e preparando (repetindo o tratamento do Exercício 11)
df = pd.read_csv('dados_sensores.csv')
df['temperatura_celsius'] = df['temperatura_celsius'].fillna(df['temperatura_celsius'].median())
df['pressao_psi'] = df['pressao_psi'].fillna(df['pressao_psi'].median())

# 2. Função auxiliar para calcular os limites do IQR
def obter_limites(coluna):
    q1 = coluna.quantile(0.25)
    q3 = coluna.quantile(0.75)
    iqr = q3 - q1
    return q1 - 1.5 * iqr, q3 + 1.5 * iqr

# 3. Calculando limites para cada coluna
li_temp, ls_temp = obter_limites(df['temperatura_celsius'])
li_pres, ls_pres = obter_limites(df['pressao_psi'])

# 4. Criando filtros de normalidade (True para quem está DENTRO dos limites)
filtro_temp = (df['temperatura_celsius'] >= li_temp) & (df['temperatura_celsius'] <= ls_temp)
filtro_pres = (df['pressao_psi'] >= li_pres) & (df['pressao_psi'] <= ls_pres)

# 5. Aplicando os filtros simultaneamente (Operador & exige que AMBAS as colunas estejam normais)
df_validado = df[filtro_temp & filtro_pres]

# 6. Exportando para CSV (index=False evita que o Pandas crie uma coluna extra de números)
df_validado.to_csv('dados_validados.csv', index=False)

print(f"Processamento concluído!")
print(f"Linhas originais: {len(df)}")
print(f"Linhas validadas (sem outliers): {len(df_validado)}")
print(f"Arquivo 'dados_validados.csv' gerado com sucesso.")